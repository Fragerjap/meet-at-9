---
name: Optimistic-update poll race
description: Pattern for preventing poll-vs-write races in AppContext that cause UI flicker.
---

## The rule
Any component that makes optimistic local-state updates AND polls the server must suppress poll overwrites while a write is in-flight.

**Why:** The poll fires on a fixed interval (3 s). If a poll response lands between the optimistic update and the write's server acknowledgment, it returns the *old* server state and reverts the UI — causing a visible flicker (color on → off → on again).

## How to apply
Use a `useRef<number>` counter (not state — to avoid re-renders):

```typescript
const pendingWrites = useRef(0);

// In every write callback:
pendingWrites.current++;
try {
  const data = await someWriteApi(...);
  setLocalState(data); // confirm with server truth
} finally {
  pendingWrites.current--;
}

// In the poll:
someReadApi().then((data) => {
  if (pendingWrites.current === 0) setLocalState(data);
});
```

This is implemented in `artifacts/mobile/context/AppContext.tsx` for `toggleCell`, `colorRange`, `clearUserCells`, and `clearAllCells`, guarding the `getMeetingGrid` poll.
